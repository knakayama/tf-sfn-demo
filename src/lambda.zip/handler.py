def hello(event, context):
    return 'Invoked with this event: {}'.format(event)
